module correo1 {
    requires javafx.base;
    requires java.mail;
    requires javafx.graphics;
    requires javafx.fxml;
    requires javafx.controls;
}