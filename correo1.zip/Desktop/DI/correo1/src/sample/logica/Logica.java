package sample.logica;

import com.sun.mail.imap.IMAPFolder;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import sample.clases.Correo;

import javax.mail.*;
import java.io.IOException;
import java.util.Properties;

public class Logica {

    private static Logica INSTANCE = null;


    private ObservableList<Correo> listaCorreos;


    private Logica() {
        listaCorreos = FXCollections.observableArrayList();

    }

    public static Logica getInstance() {
        if (INSTANCE == null)
            INSTANCE = new Logica();

        return INSTANCE;
    }

    public ObservableList<Correo> getListaCorreos() {
        return listaCorreos;
    }

    public void cargarListaCorreos() {
        IMAPFolder folder = null;
        Store store = null;
        String subject = null;
        Flags.Flag flag = null;
        try {
            Properties props = System.getProperties();
            props.setProperty("mail.store.protocol", "imaps");

            Session session = Session.getDefaultInstance(props, null);

            store = session.getStore("imaps");
            store.connect("imap.googlemail.com", "eduardocapinjavafx@gmail.com", "eduardojavafx");

            // folder = (IMAPFolder) store.getFolder("[Gmail]/Spam"); // This doesn't work for other email account
            folder = (IMAPFolder) store.getFolder("inbox"); //This works for both email account


            if (!folder.isOpen())
                folder.open(Folder.READ_WRITE);
            Message[] messages = folder.getMessages();
            Correo correo;
            for(int a=0;a<messages.length;a++)
            {
                correo=new Correo(messages[a]/*,messages[a].getSubject()*/);
                listaCorreos.add(correo);
            }




        } catch (NoSuchProviderException e) {
            e.printStackTrace();
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }
}
