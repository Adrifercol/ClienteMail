package sample.views;



import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;



public class ControllerEscribirCorreo {

    @FXML
    private Button enviarButton;

    @FXML
    private TextField para;

    @FXML
    private TextField cc;

    @FXML
    private TextArea mensaje;

    @FXML
    void enviar(ActionEvent event) {

    }

}
