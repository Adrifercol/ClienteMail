package sample.views;



import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import sample.clases.Correo;
import sample.logica.Logica;

import java.net.URL;
import java.util.ResourceBundle;

public class ControllerCorreo  implements  Initializable{

    @FXML
    private MenuItem menu;

    @FXML
    private MenuItem menuModificar;

    @FXML
    private TableView<Correo> tableViewCorreo;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Logica.getInstance().cargarListaCorreos();
        tableViewCorreo.setItems(Logica.getInstance().getListaCorreos());
    }
}
